# Telegram TTS Bot — Render pe deploy

Text / TXT / MD / PDF / DOCX / EPUB ko Telegram bot se audiobook (mp3) me badalta hai.

## Files
| File | Kaam |
|------|------|
| `tts_bot_fixed.py` | Bot ka main code |
| `render_entry.py` | Render ke liye health server + bot start |
| `Dockerfile` | Python + ffmpeg image |
| `requirements.txt` | Python libraries |
| `render.yaml` | Render ka auto-setup (Blueprint) |

Saari files GitHub repo ke **root** me rakho (`tts_bot_fixed.py` bhi usi folder me).

## Render pe chalane ke steps
1. Bot token lo: Telegram me **@BotFather** -> `/newbot`.
2. Apna user id lo: **@userinfobot**.
3. Files GitHub repo me push karo.
4. Render -> **New +** -> **Blueprint** -> apni repo chuno (ya **Web Service** -> Runtime **Docker**).
5. Environment variables bharo:
   - `BOT_TOKEN` = BotFather ka token
   - `ALLOWED_USERS` = tumhara user id (sirf tum use kar sako)
   - `LOCAL_BOT_API` = `0`
6. **Deploy**. Logs me `Bot starting` dikhe to bot chalu hai. Telegram me `/start` bhejo.

## Free plan ki limits (zaroor padho)
- Free Web Service **15 minute inactivity** ke baad so jati hai. Bot Telegram se poll karta hai, HTTP traffic nahi aata, isliye wo so jayega.
  - Fix: https://uptimerobot.com pe free monitor banao, Render URL ko har 5 minute ping karo.
  - Ya paid **Background Worker** lo (`render.yaml` me `type: worker`, `plan: starter`; tab `render_entry.py` ki jagah seedha `tts_bot_fixed.py` bhi chala sakte ho).
- Disk **temporary** hai: restart pe `/tmp` aur `settings.json` (voice/rate settings) mit jati hai. Paid plan me Disk attach karke `SETTINGS_FILE=/data/settings.json` set karo.
- Local Bot API nahi hai, isliye **upload 50 MB** aur **input file 20 MB** tak. Bahut lambi book apne aap parts me bat kar bheji jati hai.
- Free plan me CPU/RAM kam hai: `TTS_CONCURRENCY` 3-4 rakho.

## Important
- **Ek token = ek hi jagah.** Agar bot Render pe chal raha hai to GitHub Actions / local me wahi token mat chalao, warna `Conflict` / flood errors aate hain.
- Token kisi ko mat do. Pehle post me jo token ho, BotFather se `/revoke` karke naya bana lo.

## Environment variables
| Variable | Default | Matlab |
|----------|---------|--------|
| `BOT_TOKEN` | — | Zaroori |
| `ALLOWED_USERS` | khali (sab) | Allowed user ids |
| `LOCAL_BOT_API` | `0` | Render pe `0` hi rakho |
| `SESSION_MINUTES` | `0` | `0` = hamesha chale |
| `DEFAULT_VOICE` | `hi-IN-MadhurNeural` | Default voice |
| `DEFAULT_RATE` | `2.0` | Speed (0.5-2.0) |
| `TTS_CONCURRENCY` | `10` | Parallel TTS requests |
| `MAX_QUEUE` | `8` | Ek user ke max jobs |

## Bot commands
`/start /help /settings /voice /voices /rate /pitch /engine /name /demo /status /queue /cancel /clearqueue /cancelall /uptime`

## Local test
```bash
pip install -r requirements.txt     # ffmpeg bhi install hona chahiye
export BOT_TOKEN=xxxx
python tts_bot_fixed.py
```
